//
//  DGActivityIndicatorBallClipRotateMultipleAnimation.h
//  DGActivityIndicatorExample
//
//  Created by Nguyen Vinh on 7/19/15.
//  Copyright (c) 2015 Danil Gontovnik. All rights reserved.
//

#import "DGActivityIndicatorAnimation.h"

@interface DGActivityIndicatorBallClipRotateMultipleAnimation: DGActivityIndicatorAnimation

@end
