//
//  DGActivityIndicatorCookieTerminatorAnimation.h
//  DGActivityIndicatorExample
//
//  Created by tripleCC on 15/6/28.
//  Copyright (c) 2015年 Danil Gontovnik. All rights reserved.
//

#import "DGActivityIndicatorAnimation.h"

@interface DGActivityIndicatorCookieTerminatorAnimation: DGActivityIndicatorAnimation


@end
