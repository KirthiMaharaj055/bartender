//
//  BartenderDrinks+CoreDataClass.swift
//  DrinkStreet
//
//  Created by Kirthi Maharaj on 2021/08/20.
//
//

import Foundation
import CoreData


public class BartenderDrinks: NSManagedObject {

}
